package com.appperfect.petstore.create.customer;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

/**
 * @author Manoj Dhoble
 *
 */
public class CheckForm extends ActionForm
{
	private static final long serialVersionUID = 752001005000014000L;
	private String userName1;

	private String passWord;

	public void setuserName1(String userName)
	{
		this.userName1 = userName;
	}

	public void setpassWord(String passWord)
	{
		this.passWord = passWord;
	}

	public String getPassWord()
	{
		return this.passWord;
	}

	public String getUserName1()
	{
		return this.userName1;
	}

	public void reset(ActionMapping mapping, HttpServletRequest request)
	{
		this.userName1 = null;
		this.passWord = null;

	}

	public ActionErrors validate(ActionMapping mapping,
			HttpServletRequest request)
	{

		ActionErrors errors = new ActionErrors();
		if ((userName1 == null) || (userName1.length() < 1))
			errors.add("UserName", new ActionError(
					"create_login.UserName.error"));
		if ((passWord == null) || (passWord.length() < 1))
			errors.add("PassWord", new ActionError(
					"create_login.PassWord.error"));
		return errors;
	}
}