package com.appperfect.petstore.create.customer;

/**
 * @author Manoj Dhoble
 *
 */
public final class Constants
{

	/**
	 * The application scope attribute under which our user database is stored.
	 */
	public static final String HELLO_KEY = "ch03.HELLO";

}