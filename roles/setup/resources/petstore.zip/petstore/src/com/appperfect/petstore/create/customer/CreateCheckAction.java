package com.appperfect.petstore.create.customer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 * @author Manoj Dhoble
 *
 */
public final class CreateCheckAction extends Action
{

	/**
	 * Process the specified HTTP request, and create the corresponding HTTP
	 * response (or forward to another web component that will create it).
	 * Return an <code>ActionForward</code> instance describing where and how
	 * control should be forwarded, or <code>null</code> if the response has
	 * already been completed.
	 * 
	 * @param mapping
	 *            The ActionMapping used to select this instance
	 * @param actionForm
	 *            The optional ActionForm bean for this request (if any)
	 * @param request
	 *            The HTTP request we are processing
	 * @param response
	 *            The HTTP response we are creating
	 * 
	 * @exception Exception
	 *                if business logic throws an exception
	 */
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception
	{

		// These "messages" come from the ApplicationResources.properties file
//		MessageResources messages = getResources(request);

		/*
		 * Validate the request parameters specified by the user Note: Basic
		 * field validation done in HelloForm.java Business logic validation
		 * done in HelloAction.java
		 */
		ActionErrors errors = new ActionErrors();
		String username = (String) PropertyUtils.getSimpleProperty(form,
				"userName1");
		String password = (String) PropertyUtils.getSimpleProperty(form,
				"passWord");
		int i = 0;
		if (CustomerModel.li != null)
		{
			Node temp = CustomerModel.li.head;
			while (temp != null)
			{
				if ((temp.getLogin().getUserName().equals(username))
						&& (temp.getLogin().getPassword().equals(password)))
					i = 1;

				temp = temp.getNext();
			}
		}

		if (i == 0)
		{
			errors.add("person", new ActionError(
					"ch03.hello.dont.talk.to.atilla"));
			saveErrors(request, errors);
			return (new ActionForward(mapping.getInput()));
		}
		Customer.username = username;
		CustomerModel.li.setTempusername(username);
		return (mapping.findForward("validated"));

	}
}
