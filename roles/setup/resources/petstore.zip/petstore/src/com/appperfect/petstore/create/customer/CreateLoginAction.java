package com.appperfect.petstore.create.customer;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 * @author Manoj Dhoble
 *
 */
public final class CreateLoginAction extends Action
{
	public ActionForward execute(ActionMapping mapping, ActionForm form,
			HttpServletRequest request, HttpServletResponse response)
			throws Exception
	{
//		MessageResources messages = getResources(request);
		ActionErrors errors = new ActionErrors();
		String userName = (String) PropertyUtils.getSimpleProperty(form, "userName");
		String passWord1 = (String) PropertyUtils.getSimpleProperty(form, "passWord1");
//		String passWord2 = (String) PropertyUtils.getSimpleProperty(form, "passWord2");

		CustomerModel.tempusername1 = userName;
		CustomerModel.tempusername2 = passWord1;

		if (CustomerModel.li != null)
		{
			Node temp = CustomerModel.li.head;
			while (temp != null)
			{
				if (temp.getLogin().getUserName().equals(userName))
				{
					errors.add("person", new ActionError(
							"ch03.hello.username.alreadyexists"));
					saveErrors(request, errors);
					return (new ActionForward(mapping.getInput()));
				}
				temp = temp.getNext();

			}
		}
		return (mapping.findForward("DoneLogin"));

	}
}
