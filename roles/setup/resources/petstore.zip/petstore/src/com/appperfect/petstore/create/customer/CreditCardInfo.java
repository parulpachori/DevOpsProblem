package com.appperfect.petstore.create.customer;

/**
 * @author Manoj Dhoble
 *
 */
public class CreditCardInfo
{
	private String cardNumber;

	private String cardType;

	private String expiryMonth;

	private String expiryYear;

	public CreditCardInfo(String cardNumber, String cardType,
			String expiryMonth, String expiryYear)
	{
		this.cardNumber = cardNumber;
		this.cardType = cardType;
		this.expiryMonth = expiryMonth;
		this.expiryYear = expiryYear;

	}

	public String getCardNumber()
	{
		return this.cardNumber;
	}

	public String getCardType()
	{
		return this.cardType;
	}

	public String getExpiryMonth()
	{
		return this.expiryMonth;
	}

	public String getExpiryYear()
	{
		return this.expiryYear;
	}

	public void setCardNumber(String str)
	{
		this.cardNumber = str;
	}

	public void setCardType(String str)
	{
		this.cardType = str;
	}

	public void setExpiryMonth(String str)
	{
		this.expiryMonth = str;
	}

	public void setExpiryYear(String str)
	{
		this.expiryYear = str;
	}
}
