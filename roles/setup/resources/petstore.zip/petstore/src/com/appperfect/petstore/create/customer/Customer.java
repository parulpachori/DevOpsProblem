package com.appperfect.petstore.create.customer;

/**
 * @author Manoj Dhoble
 *
 */
public class Customer
{

	static String username;

	private String user;

	public void setUser(String str)
	{
		user = str;
	}

	public String getUser()
	{

		this.user = username;
		return this.user;
	}
}
