package com.appperfect.petstore.create.customer;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

/**
 * @author Manoj Dhoble
 *
 */
public final class CustomerForm extends ActionForm
{
	private static final long serialVersionUID = 752001005000014001L;
	// --------------------------------------------------- Instance Variables

	/**
	 * The person we want to say "Hello!" to
	 */
	private String firstName = null;

	private String lastName = null;

	private String streetAddress = null;

	private String city = null;

	private String stateProvince = null;

	private String country = null;

	private String zip = null;

	private String telephone = null;

	private String email = null;

	private String creditCardNumber = null;

	private String cardType = null;

	private String cardExpiryMonth = null;

	private String cardExpiryYear = null;

	private String language = null;

	private String category = null;

	private Boolean mylist = null;

	private Boolean mytips = null;

	// ----------------------------------------------------------- Properties

	/**
	 * Return the person to say "Hello!" to
	 * 
	 * @return String person the person to say "Hello!" to
	 */
	public String getCategory()
	{
		return this.category;
	}

	public String getLanguage()
	{
		return this.language;
	}

	public Boolean getMylist()
	{
		return this.mylist;
	}

	public Boolean getMytips()
	{
		return this.mytips;
	}

	public String getFirstName()
	{

		return (this.firstName);

	}

	public String getLastName()
	{
		return (this.lastName);

	}

	public String getCity()
	{
		return (this.city);

	}

	public String getStreetAddress()
	{
		return (this.streetAddress);

	}

	public String getStateProvince()
	{
		return (this.stateProvince);
	}

	public String getCountry()
	{
		return (this.country);
	}

	public String getPostalCode()
	{
		return (this.zip);
	}

	public String getEmail()
	{
		return (this.email);
	}

	public String getTelephone()
	{
		return (this.telephone);
	}

	public String getCreditCardNumber()
	{
		return (this.creditCardNumber);
	}

	public String getCardType()
	{
		return (this.cardType);
	}

	public String getCardExpiryMonth()
	{
		return (this.cardExpiryMonth);
	}

	public String getCardExpiryYear()
	{
		return (this.cardExpiryYear);
	}

	/**
	 * Set the person.
	 * 
	 * @param person
	 *            The person to say "Hello!" to
	 */
	public void setLanguage(String st)
	{
		this.language = st;
	}

	public void setCategory(String st)
	{
		this.category = st;
	}

	public void setMylist(Boolean flag)
	{
		this.mylist = flag;
	}

	public void setMytips(Boolean flag)
	{
		this.mytips = flag;
	}

	public void setFirstName(String firstName)
	{

		this.firstName = firstName;

	}

	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}

	public void setStreetAddress(String streetAddress)
	{
		this.streetAddress = streetAddress;
	}

	public void setCity(String city)
	{
		this.city = city;
	}

	public void setStateProvince(String stateProvince)
	{
		this.stateProvince = stateProvince;
	}

	public void setCountry(String country)
	{
		this.country = country;
	}

	public void setPostalCode(String postalCode)
	{
		this.zip = postalCode;
	}

	public void setEmail(String email)
	{
		this.email = email;
	}

	public void setTelephone(String telephone)
	{
		this.telephone = telephone;
	}

	public void setCreditCardNumber(String creditCardNumber)
	{
		this.creditCardNumber = creditCardNumber;
	}

	public void setCardType(String cardType)
	{
		this.cardType = cardType;
	}

	public void setCardExpiryMonth(String cardExpiryMonth)
	{
		this.cardExpiryMonth = cardExpiryMonth;
	}

	public void setCardExpiryYear(String cardExpiryYear)
	{
		this.cardExpiryYear = cardExpiryYear;
	}

	// --------------------------------------------------------- Public Methods

	/**
	 * Reset all properties to their default values.
	 * 
	 * @param mapping
	 *            The mapping used to select this instance
	 * @param request
	 *            The servlet request we are processing
	 */
	public void reset(ActionMapping mapping, HttpServletRequest request)
	{
		this.firstName = null;
		this.lastName = null;
		this.streetAddress = null;
		this.city = null;
		this.stateProvince = null;
		this.country = null;
		this.zip = null;
		this.telephone = null;
		this.email = null;
		this.creditCardNumber = null;
		this.cardType = null;
		this.cardExpiryMonth = null;
		this.cardExpiryYear = null;

	}

	/**
	 * Validate the properties posted in this request. If validation errors are
	 * found, return an <code>ActionErrors</code> object containing the
	 * errors. If no validation errors occur, return <code>null</code> or an
	 * empty <code>ActionErrors</code> object.
	 * 
	 * @param mapping
	 *            The current mapping (from struts-config.xml)
	 * @param request
	 *            The servlet request object
	 */
	public ActionErrors validate(ActionMapping mapping,
			HttpServletRequest request)
	{

		ActionErrors errors = new ActionErrors();

		if ((firstName == null) || (firstName.length() < 1))
			errors.add("FirstName", new ActionError(
					"create_customer.no.firstName.error"));
		if ((lastName == null) || (lastName.length() < 1))
			errors.add("LastName", new ActionError(
					"create_customer.no.lastName.error"));
		if ((streetAddress == null) || (streetAddress.length() < 1))
			errors.add("StreetAddress", new ActionError(
					"create_customer.no.streetAddress.error"));
		if ((city == null) || (city.length() < 1))
			errors
					.add("city", new ActionError(
							"create_customer.no.city.error"));
		if ((country == null) || (country.length() < 1))
			errors.add("country", new ActionError(
					"create_customer.no.country.error"));
		if ((stateProvince == null) || (stateProvince.length() < 1))
			errors.add("stateProvince", new ActionError(
					"create_customer.no.stateProvince.error"));
		if ((zip == null) || (zip.length() < 1))
			errors.add("zip", new ActionError("create_customer.no.zip.error"));
		if ((telephone == null) || (telephone.length() < 1))
			errors.add("telephone", new ActionError(
					"create_customer.no.telephone.error"));
		if ((email == null) || (email.length() < 1))
			errors.add("email", new ActionError(
					"create_customer.no.email.error"));
		if ((creditCardNumber == null) || (creditCardNumber.length() < 1))
			errors.add("creditCardNumber", new ActionError(
					"create_customer.no.creditCardNumber.error"));
		if ((cardExpiryMonth == null) || (cardExpiryMonth.length() < 1))
			errors.add("cardExpiryMonth", new ActionError(
					"create_customer.no.cardExpiryMonth.error"));
		if ((cardExpiryYear == null) || (cardExpiryYear.length() < 1))
			errors.add("cardExpiryYear", new ActionError(
					"create_customer.no.cardExpiryYear.error"));

		return errors;
	}
}