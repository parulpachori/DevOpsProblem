package com.appperfect.petstore.create.customer;


/**
 * @author Manoj Dhoble
 *
 */
public class CustomerInfo
{
	private String firstName;

	private String lastName;

	private String streetAddress;

	private String city;

	private String state;

	private String postalcode;

	private String country;

	private String telephone;

	private String email;

	public CustomerInfo(String firstName, String lastName,
			String streetAddress, String city, String state, String country,
			String postalcode, String email, String telephone)
	{
		this.firstName = firstName;
		this.lastName = lastName;
		this.streetAddress = streetAddress;
		this.city = city;
		this.state = state;
		this.postalcode = postalcode;
		this.country = country;
		this.telephone = telephone;

		this.email = email;

	}

	public void setFirstName(String str)
	{
		this.firstName = str;
	}

	public void setLastName(String str)
	{
		this.lastName = str;
	}

	public void setStreetAddress(String str)
	{
		this.streetAddress = str;
	}

	public void setCity(String city)
	{
		this.city = city;
	}

	public void setState(String state)
	{
		this.state = state;
	}

	public void setPostalcode(String postalcode)
	{
		this.postalcode = postalcode;
	}

	public void setCountry(String country)
	{
		this.country = country;
	}

	public void setTelephone(String telephone)
	{
		this.telephone = telephone;
	}

	public void setEmail(String email)
	{
		this.email = email;
	}

	public String getFirstName()
	{
		return this.firstName;
	}

	public String getLastName()
	{
		return this.lastName;
	}

	public String getStreetAddress()
	{
		return this.streetAddress;
	}

	public String getCity()
	{
		return this.city;
	}

	public String getState()
	{
		return this.state;
	}

	public String getPostalcode()
	{
		return this.postalcode;
	}

	public String getCountry()
	{
		return this.country;
	}

	public String getTelephone()
	{
		return this.telephone;
	}

	public String getEmail()
	{
		return this.email;
	}

}
