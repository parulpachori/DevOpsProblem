package com.appperfect.petstore.create.customer;

/**
 * @author Manoj Dhoble
 *
 */
public class CustomerList
{
	Node head;

	private static String tempusername;

	public void setTempusername(String str)
	{
		tempusername = str;
	}

	public String getTempusername(String str)
	{
		return tempusername;
	}

	public void insertNode(String userName, String passWord, String firstName,
			String lastName, String streetAddress, String city, String state,
			String country, String postalCode, String telephone, String email,
			String cardNumber, String cardType, String expiryMonth,
			String expiryYear, String Category, String Language,
			Boolean mylist, Boolean mytips)
	{

		Node insertedNode = new Node(userName, passWord, firstName, lastName,
				streetAddress, city, state, country, postalCode, telephone,
				email, cardNumber, cardType, expiryMonth, expiryYear, Category,
				Language, mylist, mytips);
		if (head == null)
		{
			head = insertedNode;
		}
		else
		{
			Node temp = head;
			while (temp.getNext() != null)
			{
				temp = temp.getNext();
			}
			temp.setNext(insertedNode);
		}

	}

	public int checkPassword(String userName, String passWord)
	{
		Node temp = head;
		while (temp != null)
		{
			if (temp.getLogin().getUserName() == userName
					&& temp.getLogin().getPassword() == passWord) return 1;
		}
		return 0;
	}

	public void printlist()
	{
		Node temp = head;
		while (temp != null)
		{

			temp = temp.getNext();
		}
	}
}