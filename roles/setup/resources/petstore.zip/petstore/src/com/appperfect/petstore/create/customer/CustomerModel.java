package com.appperfect.petstore.create.customer;

/**
 * @author Manoj Dhoble
 *
 */
public class CustomerModel
{

	// --------------------------------------------------- Instance Variables

	/**
	 * The new person we want to say "Hello!" to
	 */
	private String _FirstName = null;

	private String _LastName = null;

	private String _Address = null;

	private String _StreetAddress = null;

	private String _City = null;

	private String _Country = null;

	private String _State = null;

	private String _Pincode = null;

	private String _Telephone = null;

	private String _Email = null;

	private String _CardNumber = null;

	private String _CardType = null;

	private String _CardExpiryMonth = null;

	private String _CardExpiryYear = null;

	private String category;

	private String language;

	private Boolean mylist;

	private Boolean mytips;

	private String _UserName = null;

	private String _PassWord = null;

	static CustomerList li;

	public static String tempusername1;

	public static String tempusername2;

	// ----------------------------------------------------------- Properties

	/**
	 * Return the new person we want to say "Hello!" to
	 * 
	 * @return String person the person to say "Hello!" to
	 */
	public String getFirstName()
	{
		return this._FirstName;
	}

	public String getLastName()
	{
		return this._LastName;
	}

	public String getAddress()
	{
		return this._Address;
	}

	public String getStreetAddress()
	{
		return this._StreetAddress;
	}

	public String getCity()
	{
		return this._City;
	}

	public String getState()
	{
		return this._State;
	}

	public String getCountry()
	{
		return this._Country;
	}

	public String getPincode()
	{
		return this._Pincode;
	}

	public String getEmail()
	{
		return this._Email;
	}

	public String getTelephone()
	{
		return this._Telephone;
	}

	public String getCardNumber()
	{
		return this._CardNumber;
	}

	public String getCardType()
	{
		return this._CardType;
	}

	public String getCardExpiryMonth()
	{
		return this._CardExpiryMonth;
	}

	public String getCardExpiryYear()
	{
		return this._CardExpiryYear;
	}

	public String getCategory()
	{
		return this.category;
	}

	public String getLanguage()
	{
		return this.language;
	}

	public Boolean getMylist()
	{
		return this.mylist;
	}

	public Boolean getMytips()
	{
		return this.mytips;
	}

	public String getUserName()
	{
		return this._UserName;
	}

	public String getPassWord()
	{
		return this._PassWord;
	}

	/**
	 * Set the new person we want to say "Hello!" to
	 * 
	 * @param person
	 *            The new person we want to say "Hello!" to
	 */
	public void setFirstName(String FirstName)
	{

		this._FirstName = FirstName;

	}

	public void setLastName(String LastName)
	{

		this._LastName = LastName;

	}

	public void setAddress(String Address)
	{

		this._Address = Address;

	}

	public void setStreetAddress(String StreetAddress)
	{

		this._StreetAddress = StreetAddress;

	}

	public void setCity(String City)
	{

		this._City = City;

	}

	public void setState(String state)
	{
		this._State = state;
	}

	public void setCountry(String country)
	{
		this._Country = country;
	}

	public void setPincode(String pincode)
	{
		this._Pincode = pincode;
	}

	public void setEmail(String email)
	{
		this._Email = email;
	}

	public void setTelephone(String telephone)
	{
		this._Telephone = telephone;
	}

	public void setCardNumber(String cardnumber)
	{
		this._CardNumber = cardnumber;
	}

	public void setCardType(String cardType)
	{
		this._CardType = cardType;
	}

	public void setCardExpiryMonth(String cardexpiryMonth)
	{
		this._CardExpiryMonth = cardexpiryMonth;
	}

	public void setCardExpiryYear(String cardExpiryYear)
	{
		this._CardExpiryYear = cardExpiryYear;
	}

	public void setCategory(String str)
	{
		this.category = str;
	}

	public void setLanguage(String str)
	{
		this.language = str;
	}

	public void setMylist(Boolean flag)
	{
		this.mylist = flag;
	}

	public void setMytips(Boolean flag)
	{
		this.mytips = flag;
	}

	public void setUserName(String userName)
	{
		this._UserName = userName;
	}

	public void setPassWord(String passWord)
	{
		this._PassWord = passWord;
	}

	// --------------------------------------------------------- Public Methods

	/**
	 * This is a stub method that would be used for the Model to save the
	 * information submitted to a persistent store. In this sample application
	 * it is not used.
	 */
	public void saveToPersistentStore()
	{
		if (li == null) li = new CustomerList();
		li.insertNode(tempusername1, tempusername2, _FirstName, _LastName,
				_StreetAddress, _City, _State, _Country, _Pincode, _Telephone,
				_Email, _CardNumber, _CardType, _CardExpiryMonth,
				_CardExpiryYear, category, language, mylist, mytips);

		Customer.username = tempusername1;
		li.printlist();

	}
}