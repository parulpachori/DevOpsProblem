package com.appperfect.petstore.create.customer;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

/**
 * @author Manoj Dhoble
 *
 */
public class LoginForm extends ActionForm
{
	private static final long serialVersionUID = 752001005000014003L;
	private String userName;

	private String passWord1;

	private String passWord2;

	public void setUserName(String userName)
	{
		this.userName = userName;
	}

	public void setPassWord1(String passWord1)
	{
		this.passWord1 = passWord1;
	}

	public void setPassWord2(String passWord2)
	{
		this.passWord2 = passWord2;
	}

	public String getPassWord1()
	{
		return this.passWord1;
	}

	public String getPassWord2()
	{
		return this.passWord2;
	}

	public void reset(ActionMapping mapping, HttpServletRequest request)
	{
		this.userName = null;
		this.passWord1 = null;
		this.passWord2 = null;

	}

	public String getUserName()
	{
		return this.userName;
	}

	public ActionErrors validate(ActionMapping mapping,
			HttpServletRequest request)
	{

		ActionErrors errors = new ActionErrors();
		if ((userName == null) || (userName.length() < 1))
			errors.add("UserName", new ActionError(
					"create_login.UserName.error"));
		if ((passWord1 == null) || (passWord1.length() < 1))
			errors.add("PassWord", new ActionError(
					"create_login.PassWord.error"));
		if (!passWord1.equals(passWord2))
			errors.add("PassWordMatch", new ActionError(
					"create_login.PassWordMatch.error"));
		return errors;
	}
}