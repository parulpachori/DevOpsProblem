package com.appperfect.petstore.create.customer;

/**
 * @author Manoj Dhoble
 *
 */
public class LoginVariable
{

	private String loginName;

	public LoginVariable()
	{

		loginName = "notloggedin";
	}

	public void resetloginName()
	{
		loginName = "notloggedin";
	}

	public void setLoginName(String str)
	{

		this.loginName = str;
	}

	public String getLoginName()
	{

		return this.loginName;
	}
}
