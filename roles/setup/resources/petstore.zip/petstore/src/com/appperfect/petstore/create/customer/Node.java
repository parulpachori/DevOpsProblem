package com.appperfect.petstore.create.customer;

/**
 * @author Manoj Dhoble
 *
 */
public class Node
{
	private Login login;

	private CustomerInfo customerInfo;

	private CreditCardInfo creditCardInfo;

	private PreferenceInfo preference;

	private Node Next;

	public Node(String userName, String passWord, String firstName,
			String lastName, String streetAddress, String city, String state,
			String country, String postalCode, String telephone, String email,
			String cardNumber, String cardType, String expiryMonth,
			String expiryYear, String Category, String Language,
			Boolean mylist, Boolean mytips)
	{
		login = new Login(userName, passWord);
		customerInfo = new CustomerInfo(firstName, lastName, streetAddress,
				city, state, country, postalCode, email, telephone);
		creditCardInfo = new CreditCardInfo(cardNumber, cardType, expiryMonth,
				expiryYear);
		preference = new PreferenceInfo(Category, Language, mylist, mytips);
		Next = null;

	}

	public Node getNext()
	{
		return this.Next;
	}

	public void setNext(Node next)
	{
		this.Next = next;
	}

	public Login getLogin()
	{
		return this.login;
	}

	public CustomerInfo getCustomerInfo()
	{
		return this.customerInfo;
	}

	public CreditCardInfo getCreditCardInfo()
	{
		return this.creditCardInfo;
	}

	public PreferenceInfo getPreference()
	{
		return this.preference;
	}

}
