package com.appperfect.petstore.create.customer;

import java.util.Random;

/**
 * @author Manoj Dhoble
 *
 */
public class PersonalInf
{

	private String firstName;

	private String lastName;

	private String streetAddress;

	private String city;

	private String state;

	private String postalcode;

	private String country;

	private String telephone;

	private String email;

	private String username;

	private String cardNumber;

	private String cardType;

	private String expiryMonth;

	private String expiryYear;

	private String profileLanguage;

	private String profileCategory;

	private Boolean enablemyList;

	private Boolean enablepetTips;

	public int ordernum()
	{
		int ran;
		Random rand = new Random();
		ran = rand.nextInt(50000) % 1000;
		return ran;
	}

	public void setUsername(String s)
	{
		username = s;
		Node temp;
		temp = CustomerModel.li.head;
		while (temp != null)
		{
			if (temp.getLogin().getUserName().equals(s))
			{
				firstName = temp.getCustomerInfo().getFirstName();
				lastName = temp.getCustomerInfo().getLastName();
				streetAddress = temp.getCustomerInfo().getStreetAddress();
				city = temp.getCustomerInfo().getCity();
				state = temp.getCustomerInfo().getState();
				postalcode = temp.getCustomerInfo().getPostalcode();
				country = temp.getCustomerInfo().getCountry();
				telephone = temp.getCustomerInfo().getTelephone();
				email = temp.getCustomerInfo().getEmail();
				cardNumber = temp.getCreditCardInfo().getCardNumber();
				cardType = temp.getCreditCardInfo().getCardType();
				expiryMonth = temp.getCreditCardInfo().getExpiryMonth();
				expiryYear = temp.getCreditCardInfo().getExpiryYear();
				profileLanguage = temp.getPreference().getProfileLanguage();
				profileCategory = temp.getPreference().getProfileCategory();
				enablemyList = temp.getPreference().getEnablemyList();
				enablepetTips = temp.getPreference().getEnablepettips();
			}
			temp = temp.getNext();
		}
	}

	public String getFirstName()
	{
		return this.firstName;
	}

	public String getLastName()
	{
		return this.lastName;
	}

	public String getUsername()
	{
		return this.username;
	}	
	
	public String getStreetAddress()
	{
		return this.streetAddress;
	}

	public String getCity()
	{
		return this.city;
	}

	public String getState()
	{
		return this.state;
	}

	public String getPostalcode()
	{
		return this.postalcode;
	}

	public String getCountry()
	{
		return this.country;
	}

	public String getTelephone()
	{
		return this.telephone;
	}

	public String getEmail()
	{
		return this.email;
	}

	public String getCardNumber()
	{
		return this.cardNumber;
	}

	public String getCardType()
	{
		return this.cardType;
	}

	public String getExpiryMonth()
	{
		return this.expiryMonth;
	}

	public String getExpiryYear()
	{
		return this.expiryYear;
	}

	public String getProfileLanguage()
	{
		return this.profileLanguage;
	}

	public String getProfileCategory()
	{
		return this.profileCategory;
	}

	public Boolean getEnablemyList()
	{
		return this.enablemyList;
	}

	public Boolean getEnablepetTips()
	{
		return this.enablepetTips;
	}

}
