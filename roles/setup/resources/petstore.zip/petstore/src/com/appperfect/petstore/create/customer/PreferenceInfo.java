package com.appperfect.petstore.create.customer;

/**
 * @author Manoj Dhoble
 *
 */
public class PreferenceInfo
{

	private String profileCategory;

	private String profileLanguage;

	private Boolean enablemyList;

	private Boolean enablepetTips;

	public PreferenceInfo(String category, String language, Boolean list,
			Boolean tips)
	{
		this.profileCategory = category;
		this.profileLanguage = language;
		this.enablemyList = list;
		this.enablepetTips = tips;
		Boolean b = new Boolean(false);
		if (list == null)
		{
			this.enablemyList = b;
		}
		if (tips == null)
		{
			this.enablepetTips = b;
		}

	}

	public PreferenceInfo()
	{
	}

	public void setProfileCategory(String str)
	{
		this.profileCategory = str;
	}

	public void setProfileLanguage(String str)
	{
		this.profileLanguage = str;
	}

	public void setEnablemyList(Boolean flag)
	{
		this.enablemyList = flag;
	}

	public void setEnablepettips(Boolean flag)
	{
		this.enablepetTips = flag;
	}

	public Boolean getEnablepettips()
	{
		return this.enablepetTips;
	}

	public Boolean getEnablemyList()
	{
		return this.enablemyList;
	}

	public String getProfileLanguage()
	{
		return this.profileLanguage;
	}

	public String getProfileCategory()
	{
		return this.profileCategory;
	}

}
