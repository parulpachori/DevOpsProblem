package com.appperfect.petstore.create.customer;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;

/**
 * @author Manoj Dhoble
 *
 */
public final class ShippingForm extends ActionForm
{
	private static final long serialVersionUID = 752001005000014005L;
	
	private String firstName = null;

	private String lastName = null;

	private String streetAddress = null;

	private String city = null;

	private String stateProvince = null;

	private String country = null;

	private String zip = null;

	private String telephone = null;

	private String email = null;

	private String username;

	private String firstName1 = null;

	private String lastName1 = null;

	private String streetAddress1 = null;

	private String city1 = null;

	private String stateProvince1 = null;

	private String country1 = null;

	private String zip1 = null;

	private String telephone1 = null;

	private String email1 = null;

	// ----------------------------------------------------------- Properties

	/**
	 * Return the person to say "Hello!" to
	 * 
	 * @return String person the person to say "Hello!" to
	 */
	public String getFirstName()
	{
		return (this.firstName);
	}

	public String getLastName()
	{
		return (this.lastName);
	}

	public String getCity()
	{
		return (this.city);
	}

	public String getStreetAddress()
	{
		return (this.streetAddress);
	}

	public String getStateProvince()
	{
		return (this.stateProvince);
	}

	public String getCountry()
	{
		return (this.country);
	}

	public String getPostalCode()
	{
		return (this.zip);
	}

	public String getEmail()
	{
		return (this.email);
	}

	public String getTelephone()
	{
		return (this.telephone);
	}

	public String getFirstName1()
	{
		return (this.firstName1);
	}

	public String getLastName1()
	{
		return (this.lastName1);
	}

	public String getCity1()
	{
		return (this.city1);
	}

	public String getStreetAddress1()
	{
		return (this.streetAddress1);
	}

	public String getStateProvince1()
	{
		return (this.stateProvince1);
	}

	public String getCountry1()
	{
		return (this.country1);
	}

	public String getPostalCode1()
	{
		return (this.zip1);
	}

	public String getEmail1()
	{
		return (this.email1);
	}

	public String getTelephone1()
	{
		return (this.telephone1);
	}

	public String getUsername()
	{
		return this.username;
	}

	public void setUsername(String str)
	{
		this.username = str;
	}

	/**
	 * Set the person.
	 * 
	 * @param person
	 *            The person to say "Hello!" to
	 */
	public void setFirstName(String firstName)
	{

		this.firstName = firstName;

	}

	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}

	public void setStreetAddress(String streetAddress)
	{
		this.streetAddress = streetAddress;
	}

	public void setCity(String city)
	{
		this.city = city;
	}

	public void setStateProvince(String stateProvince)
	{
		this.stateProvince = stateProvince;
	}

	public void setCountry(String country)
	{
		this.country = country;
	}

	public void setPostalCode(String postalCode)
	{
		this.zip = postalCode;
	}

	public void setEmail(String email)
	{
		this.email = email;
	}

	public void setTelephone(String telephone)
	{
		this.telephone = telephone;
	}

	public void setFirstName1(String firstName)
	{

		this.firstName1 = firstName;

	}

	public void setLastName1(String lastName)
	{
		this.lastName1 = lastName;
	}

	public void setStreetAddress1(String streetAddress)
	{
		this.streetAddress1 = streetAddress;
	}

	public void setCity1(String city)
	{
		this.city1 = city;
	}

	public void setStateProvince1(String stateProvince)
	{
		this.stateProvince1 = stateProvince;
	}

	public void setCountry1(String country)
	{
		this.country1 = country;
	}

	public void setPostalCode1(String postalCode)
	{
		this.zip1 = postalCode;
	}

	public void setEmail1(String email)
	{
		this.email1 = email;
	}

	public void setTelephone1(String telephone)
	{
		this.telephone1 = telephone;
	}

	// --------------------------------------------------------- Public Methods

	/**
	 * Reset all properties to their default values.
	 * 
	 * @param mapping
	 *            The mapping used to select this instance
	 * @param request
	 *            The servlet request we are processing
	 */
	public void reset(ActionMapping mapping, HttpServletRequest request)
	{
		this.firstName = null;
		this.lastName = null;
		this.streetAddress = null;
		this.city = null;
		this.stateProvince = null;
		this.country = null;
		this.zip = null;
		this.telephone = null;
		this.email = null;
		this.firstName1 = null;
		this.lastName1 = null;
		this.streetAddress1 = null;
		this.city1 = null;
		this.stateProvince1 = null;
		this.country1 = null;
		this.zip1 = null;
		this.telephone1 = null;
		this.email1 = null;

	}

	/**
	 * Validate the properties posted in this request. If validation errors are
	 * found, return an <code>ActionErrors</code> object containing the
	 * errors. If no validation errors occur, return <code>null</code> or an
	 * empty <code>ActionErrors</code> object.
	 * 
	 * @param mapping
	 *            The current mapping (from struts-config.xml)
	 * @param request
	 *            The servlet request object
	 */
	public ActionErrors validate(ActionMapping mapping,
			HttpServletRequest request)
	{

		ActionErrors errors = new ActionErrors();

		if ((firstName == null) || (firstName.length() < 1))
			errors.add("FirstName", new ActionError(
					"create_customer.no.firstName.error"));
		if ((lastName == null) || (lastName.length() < 1))
			errors.add("LastName", new ActionError(
					"create_customer.no.lastName.error"));
		if ((streetAddress == null) || (streetAddress.length() < 1))
			errors.add("StreetAddress", new ActionError(
					"create_customer.no.streetAddress.error"));
		if ((city == null) || (city.length() < 1))
			errors
					.add("city", new ActionError(
							"create_customer.no.city.error"));
		if ((country == null) || (country.length() < 1))
			errors.add("country", new ActionError(
					"create_customer.no.country.error"));
		if ((stateProvince == null) || (stateProvince.length() < 1))
			errors.add("stateProvince", new ActionError(
					"create_customer.no.stateProvince.error"));
		if ((zip == null) || (zip.length() < 1))
			errors.add("zip", new ActionError("create_customer.no.zip.error"));
		if ((telephone == null) || (telephone.length() < 1))
			errors.add("telephone", new ActionError(
					"create_customer.no.telephone.error"));
		if ((email == null) || (email.length() < 1))
			errors.add("email", new ActionError(
					"create_customer.no.email.error"));
		if ((firstName1 == null) || (firstName1.length() < 1))
			errors.add("FirstName", new ActionError(
					"create_customer.no.firstName.error"));
		if ((lastName1 == null) || (lastName1.length() < 1))
			errors.add("LastName", new ActionError(
					"create_customer.no.lastName.error"));
		if ((streetAddress1 == null) || (streetAddress1.length() < 1))
			errors.add("StreetAddress", new ActionError(
					"create_customer.no.streetAddress.error"));
		if ((city1 == null) || (city1.length() < 1))
			errors
					.add("city", new ActionError(
							"create_customer.no.city.error"));
		if ((country1 == null) || (country1.length() < 1))
			errors.add("country", new ActionError(
					"create_customer.no.country.error"));
		if ((stateProvince1 == null) || (stateProvince1.length() < 1))
			errors.add("stateProvince", new ActionError(
					"create_customer.no.stateProvince.error"));
		if ((zip1 == null) || (zip1.length() < 1))
			errors.add("zip", new ActionError("create_customer.no.zip.error"));
		if ((telephone1 == null) || (telephone1.length() < 1))
			errors.add("telephone", new ActionError(
					"create_customer.no.telephone.error"));
		if ((email1 == null) || (email1.length() < 1))
			errors.add("email", new ActionError(
					"create_customer.no.email.error"));

		return errors;
	}
}
