package com.appperfect.petstore.petstorage.pit;

import java.io.Serializable;

/**
 * @author Manoj Dhoble
 *
 */
public class Data implements Serializable
{
	private static final long serialVersionUID = 752001005000014006L;
	
	private static int counter;

	private String name;

	private int id;

	private String description;

	private double pricelist;

	private double yourprice;

	private String image;

	private String tip;

	public Data(String name, String description, double pricelist,
			double yourprice, String image, String tip)
	{
		this.id = ++counter;
		this.name = name.trim();
		this.description = description.trim();
		this.pricelist = pricelist;
		this.yourprice = yourprice;
		this.image = image.trim();
		this.tip = tip.trim();
	}

	public int getId()
	{
		return id;
	}

	public String getName()
	{
		return name;
	}

	public String getname()
	{
		return name;
	}

	public String getDescription()
	{
		return description;
	}

	public double getPricelist()
	{
		return pricelist;
	}

	public double getYourprice()
	{
		return yourprice;
	}

	public String getImage()
	{
		return image;
	}

	public String getTip()
	{
		return tip;
	}
}
