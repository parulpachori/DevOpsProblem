package com.appperfect.petstore.petstorage.pit;

import javax.swing.tree.DefaultMutableTreeNode;

/**
 * @author Manoj Dhoble
 *
 */
public class Node extends DefaultMutableTreeNode
{
	private static final long serialVersionUID = 752001005000014007L;
	
	public Node(String name, String description, double pricelist,
			double yourprice, String image, String tip)
	{
		Data temp = new Data(name, description, pricelist, yourprice, image,
				tip);
		this.userObject = temp;
	}
}
