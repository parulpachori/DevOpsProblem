package com.appperfect.petstore.petstorage.pit;

import java.util.ArrayList;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

/**
 * @author Manoj Dhoble
 *
 */
public class petTree extends DefaultTreeModel
{
	private static final long serialVersionUID = 752001005000014008L;
	
	private Data information;

	public DefaultMutableTreeNode found;

	public petTree(Node t)
	{
		super(t);
	}

	public void find(String findString, Node traverse)
	{
		if (traverse != null)
		{
			Data tempData = (Data) (traverse.getUserObject());

			if (tempData.getName().equals(findString))
			{
				found = traverse;

				return;
			}
			else
			{
				for (int i = 0; i < traverse.getChildCount(); i++)
				{
					find(findString, (Node) traverse.getChildAt(i));
				}
			}
		}

	}

	public void find(int findId, Node traverse)
	{
		if (traverse != null)
		{
			Data tempData = (Data) (traverse.getUserObject());

			if (tempData.getId() == findId)
			{
				found = traverse;

				return;
			}
			else
			{
				for (int i = 0; i < traverse.getChildCount(); i++)
				{
					find(findId, (Node) traverse.getChildAt(i));
				}
			}
		}

	}

	public Data getInformation(int id)
	{
		found = null;
		find(id, (Node) root);
		information = (Data) found.getUserObject();
		return information;
	}

	public void insert(Node temp, String parentNode)
	{

	}

	public void printTree(Node no)
	{
		if (no != null)
		{
//			Node temp = (Node) no;
//			Data d = (Data) temp.getUserObject();
			for (int i = 0; i < no.getChildCount(); i++)
			{
				printTree((Node) no.getChildAt(i));

			}
		}
	}

	public ArrayList printChildren(Node n)
	{
		ArrayList a = new ArrayList();
		for (int i = 0; i < n.getChildCount(); i++)
		{
			Node temp = (Node) n.getChildAt(i);
			Data data = (Data) temp.getUserObject();
			a.add(data);

		}
		return a;
	}
}
