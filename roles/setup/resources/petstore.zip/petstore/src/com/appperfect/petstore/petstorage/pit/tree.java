package com.appperfect.petstore.petstorage.pit;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.swing.tree.DefaultMutableTreeNode;

import com.appperfect.petstore.create.customer.CustomerModel;

/**
 * @author Manoj Dhoble
 *
 */
public class tree extends HttpServlet
{
	private static final long serialVersionUID = 752001005000014010L;
	
	DefaultMutableTreeNode t;

	public static petTree pet;

	String tempChildSearch;

	private Data information;

//	private Data value;

	private ArrayList animals;

	private ArrayList children;

	private static String search;

	private String infoString;

	FileReader file;

	BufferedReader br = null;

	public void init(ServletConfig sc) throws ServletException
	{
		super.init(sc);
		ServletContext context = sc.getServletContext();

		if (pet == null)
		{
			FileReader file;
			file = null;
			BufferedReader br = null;

			try
			{
				file = new FileReader(context.getRealPath("/WEB-INF/file.txt"));
				br = new BufferedReader(file);
				System.out
						.println("petstorage file(file.txt) found and loading...");
			}
			catch (Exception e)
			{
				System.out
						.println("error file not found....failed to load petstore");
			}
			finally
			{
				try
				{
					double plist, ylist;
//					int count = 0;
					String name;
					while ((name = br.readLine()) != null)
					{
						String description = br.readLine();
						String pricelist = br.readLine();
						if (pricelist.length() > 0)
							plist = Double.parseDouble(pricelist);
						else
							plist = -1;// used to detect not a leaf node
						String yourprice = br.readLine();
						if (yourprice.length() > 0)
							ylist = Double.parseDouble(yourprice);
						else
							ylist = -1;// used to detect not a leaf node
						String image = br.readLine();
						String tip = br.readLine();
						String parent = br.readLine();
						if (name.length() > 0)
						{
//							int d = 0;
							Node tempNode = new Node(name, description, plist,
									ylist, image, tip);
							if (pet == null)
							{
								pet = new petTree(tempNode);

							}
							else
							{

								pet.found = null;
								pet.find(parent, (Node) pet.getRoot());
								if (pet.found != null)
								{
									Node n = (Node) pet.found;
									int noofChildren = n.getChildCount();
									pet.insertNodeInto(tempNode, n,
											noofChildren);
								}
								else
								{

								}
							}// end of else

						}// end of if
						br.readLine();
					}// end of while
					br.close();
					file.close();

					CustomerModel hm = new CustomerModel();
					CustomerModel.tempusername1 = "j2ee";
					CustomerModel.tempusername2 = "j2ee";
					hm.setFirstName("Duke");
					hm.setLastName("BluePrints");
					hm.setStreetAddress("1234 MoonWay");
					hm.setCity("Sunville");
					hm.setState("California");
					hm.setCountry("USA");
					hm.setPincode("100001");
					hm.setEmail("aaa@bbb.ccc");
					hm.setTelephone("408-555-5555");
					hm.setCardNumber("0100-001-0001");
					hm.setCardType("JAVA CARD");
					hm.setCardExpiryMonth("01");
					hm.setCardExpiryYear("2002");
					hm.setCategory("Reptiles");
					hm.setLanguage("en_US");
					Boolean b = new Boolean(true);
					hm.setMylist(b);
					hm.setMytips(b);
					hm.saveToPersistentStore();
				}
				catch (Exception e)
				{
					System.out.println("error has occured");
				}// end of try inside finally
			}// end of finally
		}// end of if
	}// end of method

	public void setSearch(String s)
	{
		search = s;
	}

	public void setInfoString(String st)
	{
		infoString = st;
	}

	public void setAnimals()
	{

	}

	public void setChildren(String s)
	{
		tempChildSearch = s;
		children = null;
	}

	public void setChildren()
	{

		children = null;
	}

	public void setChildren(ArrayList a)
	{
		tempChildSearch = "DOGS";
		children = null;
	}

	public ArrayList getAnimals() throws Exception
	{
		animals = new ArrayList();
		// init();
		animals = pet.printChildren((Node) pet.getRoot());
		return animals;
	}

	public Data getInformation()
	{
		pet.found = null;
		pet.find(infoString.trim(), (Node) pet.getRoot());
		information = (Data) pet.found.getUserObject();
		return information;
	}

	public Data getValue()
	{
		pet.found = null;
		pet.find(infoString.trim(), (Node) pet.getRoot());
		information = (Data) pet.found.getUserObject();
		return information;
	}

	public Data getinformation()
	{
		try
		{
			pet.found = null;
			pet.find(infoString.trim(), (Node) pet.getRoot());
			information = (Data) pet.found.getUserObject();
			return information;
		}
		catch (Exception e)
		{
			System.out.println("exception has occured");
			e.printStackTrace(System.out);

			return information;
		}
	}

	public Data getInformation(int id)
	{
		pet.found = null;
		pet.find(id, (Node) pet.getRoot());
		information = (Data) pet.found.getUserObject();
		return information;
	}

	public ArrayList getChildren()
	{
		try
		{
			tempChildSearch = search;
			pet.found = null;
			pet.find(tempChildSearch.trim(), (Node) pet.getRoot());
			children = pet.printChildren((Node) pet.found);
			return children;

		}
		catch (Exception e)
		{
			System.out.println("exception has occured");
			e.printStackTrace(System.out);
			return children;
		}

	}

	public void print()
	{
		pet.printTree((Node) pet.getRoot());
	}

}
