package com.appperfect.petstore.shopping;


/**
 * @author Manoj Dhoble
 *
 */
public class Node
{

	private int numberItems;

	private int itemId;

	private String name;

	private double priceoffered;

	private Node next;

	public Node getNext()
	{
		return this.next;
	}

	public void setNext(Node n)
	{
		this.next = n;
	}

	public void setNumberofItems(int i)
	{
		this.numberItems = i;
	}

	public Node(int itemId, double priceoffered, String Name)
	{
		this.numberItems = 1;
		this.itemId = itemId;
		this.priceoffered = priceoffered;
		this.name = Name;
	}

	public void numberincrement()
	{

		this.numberItems++;
	}

	public int getNumberItems()
	{
		return this.numberItems;
	}

	public int getItemId()
	{
		return this.itemId;
	}

	public double getPriceoffered()
	{
		return this.priceoffered;
	}

	public String getName()
	{
		return this.name;
	}
}
