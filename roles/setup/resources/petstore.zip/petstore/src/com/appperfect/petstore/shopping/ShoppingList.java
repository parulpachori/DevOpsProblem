package com.appperfect.petstore.shopping;

import java.util.ArrayList;

import com.appperfect.petstore.petstorage.pit.Data;
import com.appperfect.petstore.petstorage.pit.tree;

/**
 * @author Manoj Dhoble
 *
 */
public class ShoppingList
{
	Node head;

	private String identity;

	private ArrayList mshoppingList;

	private int updateid;

	private int updatevalue;

	private double totalcost;

	private String user;

	private int removal;

	public void setRemoval(int id)
	{
		removal = id;
		remove(removal);
	}

	public void reset()
	{
		head = null;
		identity = null;
		mshoppingList = null;
		updatevalue = 0;
		updateid = 0;
		totalcost = 0;
		user = null;

	}

	public void setUser(String str)
	{
		this.user = str;
	}

	public String getUser(String str)
	{
		return this.user;
	}

	public double getTotalcost()
	{
		Node temp = head;
		totalcost = 0;
		while (temp != null)
		{
			totalcost = totalcost
					+ (temp.getNumberItems() * temp.getPriceoffered());
			temp = temp.getNext();
		}
		return totalcost;
	}

	public void setMshoppingList()
	{
	}

	public void setUpdateid(String id)
	{

		updateid = Integer.parseInt(id);

	}

	public void setUpdatevalue(String id)
	{

		updatevalue = Integer.parseInt(id);
		performupdate(updateid, updatevalue);
	}

	public int performupdate(int iden, int upvalue)
	{
		Node temp = head;
		while (temp != null)
		{
			if (temp.getItemId() == iden)
			{
				temp.setNumberofItems(upvalue);
				return 1;
			}
			else
				temp = temp.getNext();
		}
		return 0;
	}

	public ArrayList getMshoppingList()
	{
		mshoppingList = new ArrayList();
		Node temp = head;
		while (temp != null)
		{
			mshoppingList.add(temp);
			temp = temp.getNext();
		}
		return mshoppingList;

	}

	public void setIdentity(String str)
	{
		if (!str.equals("updatecart"))
		{

			this.identity = str;

			searchandadd(Integer.parseInt(identity));
		}
	}

	public String getIdentity()
	{

		return identity;
	}

	public void insert(Node traverse, Node insert)
	{
		if (head == null)
		{

			head = insert;
			return;
		}
		while (traverse.getNext() != null)
		{
			traverse = traverse.getNext();
		}
		traverse.setNext(insert);

	}

	public int existancecheck(int id)
	{
		Node temp = head;
		while (temp != null)
		{
			if (temp.getItemId() == id)
			{

				temp.numberincrement();
				return 1;
			}
			else
				temp = temp.getNext();
		}
		return 0;
	}

	public void searchandadd(int id)
	{

		Data tempdata;
		if (tree.pet != null)
		{
			tempdata = tree.pet.getInformation(id);

			int i = existancecheck(id);

			if (i == 0)
			{
				Node tempNode = new Node(tempdata.getId(), tempdata
						.getYourprice(), tempdata.getName());
				insert(head, tempNode);

			}
		}

	}

	public void remove(int id)
	{
//		Data tempdata;
		if (tree.pet != null)
		{
			Node temp = head;
			Node prev = head;
			if (head.getItemId() == id)
			{
				head = head.getNext();
			}
			else
			{
				while (temp.getItemId() != id)
				{
					prev = temp;
					temp = temp.getNext();
				}
				prev.setNext(temp.getNext());
				temp.setNext(null);
			}
		}
	}
}
